#ifdef CHANGED

#include "syscall.h"

int main()
{
	//PutString("fezfez");
	PutString("grezgre");
	return 0;
}

#endif // CHANGED
